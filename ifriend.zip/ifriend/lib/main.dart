import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'iFriend',
      theme: ThemeData(
        // Definindo o fundo como preto
        scaffoldBackgroundColor: Colors.black,
        // Definindo a cor do texto como branco
        textTheme: TextTheme(
          bodyText1: TextStyle(color: Colors.white),
          bodyText2: TextStyle(color: Colors.white),
          headline6: TextStyle(color: Colors.white),
        ),
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // Definindo a cor de fundo da app bar como verde forte
        backgroundColor: const Color.fromARGB(255, 98, 231, 45),
        title: Text('Login',),
        centerTitle: true,

      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Recuo para a direita dos campos de email e senha
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Expanded(
                    child: TextField(
                      controller: _emailController,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        labelStyle: TextStyle(color: Color.fromARGB(255, 98, 231, 45)),
                      ),
                      style: TextStyle(color: Color.fromARGB(255, 98, 231, 45)), // Definindo a cor do texto como branco
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Expanded(
                    child: TextField(
                      controller: _passwordController,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        labelStyle: TextStyle(color: Color.fromARGB(255, 98, 231, 45)),
                      ),
                      obscureText: true,
                      style: TextStyle(color: Color.fromARGB(255, 87, 224, 32)), // Definindo a cor do texto como branco
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: () {
                  // Aqui você pode adicionar a lógica para autenticar o usuário
                  // utilizando os dados inseridos nos campos de texto.
                  // Por enquanto, este é apenas um exemplo básico.
                  print('Email: ${_emailController.text}');
                  print('Password: ${_passwordController.text}');
                },
                child: Text('Login'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
