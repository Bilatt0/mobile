package com.example.ifriend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
